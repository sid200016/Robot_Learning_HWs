All Default Scripts provided in 16831_hw2.pdf were used to run experiments (except for question 7 and 8 due to typos in pdf).
To run experiments to look for optimal batch and lr values, a shell script was used -> rob831/scripts/run_q4_grid.sh. 
To run experiments to scan over lambda values, another shell script was used -> rob831/scripts/run_q5.sh